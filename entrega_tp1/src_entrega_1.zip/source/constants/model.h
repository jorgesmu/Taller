// Aca definimos las constantes que tengan que ver con modelizacion y demas

const float CONST_DT = 0.166666; // Fixed timestep