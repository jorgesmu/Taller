#pragma once

#include <fstream>
#include "yaml-cpp/yaml.h"

//Intenta leer un archivo de prueba
void parser_test();