#include "config_juego.h"
#include <string>
//Constructor
config_juego::config_juego() {
		pantalla.set_alto(-1);
		pantalla.set_ancho(-1);
		config.set_margen_scroll(-1);
		config.set_vel_personaje(-1);
};